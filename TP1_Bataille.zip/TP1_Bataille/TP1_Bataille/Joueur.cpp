#include "Joueur.h"

Joueur::Joueur(std::string p, Carte* c) : nom(p)
{
	_carte = c;
}


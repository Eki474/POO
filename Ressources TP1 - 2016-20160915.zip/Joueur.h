#pragma once
#include "Carte.h"
#include <string>
#include <iostream>
#include <sstream>


class Joueur
{

};

